package test;

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* Solution Tester. 
* 
* @author <Authors name> 
* @since <pre>Mar 8, 2018</pre> 
* @version 1.0 
*/ 
public class SolutionTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: main(String[] args) 
* 
*/ 
@Test
public void testMain() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setUpDic(HashSet<String> dic) 
* 
*/ 
@Test
public void testSetUpDic() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: copy(LinkedList<String> from, LinkedList<String> to) 
* 
*/ 
@Test
public void testCopy() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: print(LinkedList<String> ladder) 
* 
*/ 
@Test
public void testPrint() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: ladder(HashSet<String> dic, String start, String end) 
* 
*/ 
@Test
public void testLadder() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: checkValid(HashSet<String> dic, String start, String end) 
* 
*/ 
@Test
public void testCheckValid() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: neighbors(String word, HashSet<String>dic) 
* 
*/ 
@Test
public void testNeighbors() throws Exception { 
//TODO: Test goes here... 
} 


} 
